<?php

class User {
    public $id, $name, $surname, $acc, $personalId, $balance;
}