<div class="topnav">
    <a class="active" href="<?=URL?>">Pagrindinis</a>
    <a href="<?=URL?>create">Sukurti naują sąskaita</a>
    <!-- <a href="<?=URL?>incoming.php">pridėti lėšas</a>
<a href="<?=URL?>cashOut.php">nuskaičiuoti lėšas</a> -->
    <a href="<?=URL?>">sąskaitų sąrašas</a>
</div>