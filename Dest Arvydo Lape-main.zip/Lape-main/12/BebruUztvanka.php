<?php

require __DIR__.'/functions.php';

router();