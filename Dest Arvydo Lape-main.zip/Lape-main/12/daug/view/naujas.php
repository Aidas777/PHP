<?php require __DIR__ . '/virsus.php' ?>

<form action="<?= URL ?>?route=nauja" method="post">
    <div>
        <button type="submit">Sukurti naują užtvanką</button>
    </div>
</form>

<?php require __DIR__ . '/apacia.php' ?>