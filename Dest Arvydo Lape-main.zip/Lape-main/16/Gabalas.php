<?php
namespace Asteroidas;

trait Gabalas{

    public function gabalas() 
    {
        _d('Čia buvo treito gabalas');
    }

}