<?php
namespace Galaktika;

interface Radijus {

    function radio();

}