<?php
namespace Galaktika;


interface Televizija {

    const MARYTE = 8;

    function kaTu();

}