<?php
use Bebru\Uztvanka\App;
require __DIR__ . '/../bootstrap.php';


App::start();





