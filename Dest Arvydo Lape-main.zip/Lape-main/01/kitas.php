<?php


echo '<h1>Viso gero</h1>';




$labas = 2;


echo $labas++ * ++$labas;
// 2 * 4


// echo ++$labas;
echo '<br>';
// echo $labas;


$pirmas = 'bla bla';
$antras = 'ku kū';
$trecias = $pirmas . $antras;


echo $trecias;


