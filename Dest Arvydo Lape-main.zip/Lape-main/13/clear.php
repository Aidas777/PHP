<?php
require __DIR__ . '/functions.php';
clearCache();