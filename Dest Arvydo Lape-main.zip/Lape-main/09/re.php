<?php

header('Location: http://localhost/Lape/09/page.php?pus=1');
die;