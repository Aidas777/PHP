<?php require __DIR__ . '/virsus.php' ?>

<div class="container">
    <div class="row">
        <div class="col-5">
            <h1>Sveiki atvykę į bebrų užtvanką</h1>
        </div>
    </div>
</div>


<?php require __DIR__ . '/apacia.php' ?>