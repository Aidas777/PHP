<?php
namespace Kosmosas;

class Bliudas {
    public $bliudas = 'Palydovo televizija';
}