<?php
session_start();
require __DIR__.'/functions.php';

define('URL', 'http://localhost/Lape/14/BebruUztvanka.php');

router();