<?php

// echo $_COOKIE['bananas'];

echo date('h:i:s', time() - 60);


setcookie('bananas', 'raudonas', time() - 60, '/');


