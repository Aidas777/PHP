<?php

require __DIR__.'/functions.php';

define('URL', 'http://localhost/Lape/12/daug/BebruUztvanka.php');

router();